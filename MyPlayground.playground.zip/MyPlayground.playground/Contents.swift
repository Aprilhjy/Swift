import Cocoa

var str = "Hello, playground"

var firstname = "Tom"
print(firstname)

var stockprice = 100
print(stockprice)

stockprice = 50
print(stockprice)

let lastname = "smith"

let a = 20
let b = 10
if a <= 10 || b < 5 {
    print("a is less than 10")
}
else if a < 15 {
    print ("a is less than 15")
}

else {
    print ("a is greater than 15")
}

let char = "b"
switch char {
case "a":
    print("this is a")
case "b", "c":
    print("this is b or c")
default:
    print("this is the fallback")
}

var sum = 0
for counter in 1...5{
    
    sum += counter
    print(sum)
}

var counter = -5
while counter > 0{
    print("hello from while loop")
    counter -= 1
    
}

var counter2 = -5

repeat {
    print("hello from repeat while loop")
    counter2 -= 1
} while counter2 > 0

func addTwoNumbers(_ number1: Int, _ number2: Int) -> Int{
    let a = number1
    let b = number2
    let c = a + b
    
    return c
}

let sumResult = addTwoNumbers(89, 56)
print(sumResult)

