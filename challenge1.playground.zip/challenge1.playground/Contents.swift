import Cocoa

var lastName: String = "He"

var firstName: String = "Ye"

let gender: String = "Male"

var age: Int = 80

var hasChildren: Bool = false

if hasChildren == true {
    print("Being hard, my money goes to my children instead of games")
}

else if age > 18 {
    print("Adulting is hard I can't buy the game because I need to pay bills")
}
else{
    "I'm young and I can do what I want so gimme that game!"
}

var strOperator: String = "/"

var num1: Int = 578

var num2: Int = 897

var result: Int

switch strOperator {
case "+":
    result = num1 + num2
    print(result)
case "-":
    result = num2 - num1
    print(result)
case "*", "x":
    result = num1 * num2
    print(result)
case "/":
    result = num2 / num1
    print(result)
case "^":
    result = num1 ^ 2
    print(result)
default:
    print("Operator does not exist")
}

var drawPixel: String = "*"
var height: Int = 10
var tempRow: String = ""

for columnPixel in 1...height {
    tempRow = ""
    for _ in 1...columnPixel {
        tempRow += drawPixel
    }
    print(tempRow)
}

// challenge 6: Investment forecast

var cashOnHand: Double = 2000
var runningCash: Double
var percentGain: Double = 10
var yearsToInvest: Int = 5
var yearsElapsed: Int = 0

runningCash = cashOnHand
percentGain = percentGain / 100

repeat {
    runningCash = runningCash + (percentGain * runningCash)
    print(runningCash)
    yearsElapsed += 1
} while yearsElapsed < yearsToInvest

func walkNorth() {
    
    print("You walked North")
}
walkNorth()

func walkSouth() {
    print("You walked South")
}
walkSouth()

func walkEast() {
    print("You walked East")
}
walkEast()

func walkWest() {
    print("You walked West")
}
walkWest()

func walk (_ direction: String, _ steps: Int) -> String {
    return "You have walked " + String(steps) + " steps to the " + direction
}
let resultStr: String = walk("North", 5)
print(resultStr)

class people {
    var name = ""
    init() {
        
    }
    init(_ name: String) {
        // custom init code
        self.name = name
       
    }
    
}
class Employee: people {
    var salary = 0
    var role = ""
    
    
    func doWork () {
        print("Hello I am \(name) and I am working hard")
        salary == 100
    }
}
let a: Int = 10
let b: String = "Ted"
var c: Employee = Employee()

c.name = "jiaying"
c.salary = 90000
print(c.name)
print(c.salary)

c.doWork()

var d = Employee()
d.name = "Winnie"
d.salary = 789000
d.role = "manager"
d.doWork()

class Manager: Employee {
    
    var teamsize = 0
    var bonus:Int {
        // This is a computed property
        // When it's accessed, the code in here will run
        // Then we will return the value
        
        return teamsize * 1000
    }
    
    init (_ name:String, _ team:Int){
        // This calls the init if the Employee class
        super.init(name)
        
        // Additional init work
        teamsize = team
    }
    override func doWork() {
        super.doWork()
        print("I am managing people")
        salary += 300
    }
    
    func firepeople() {
        print ("I am firing people ooho")
    }
}

let myperson = people("Tommy")
print(myperson.name)

let made = Manager ("xiaoming", 90 )
print(made.bonus)


//var e = Manager()
//e.name = "Jimmuy"
//e.salary = 1000000
//e.role = "Manager of IT"
//e.teamsize = 100
//e.firepeople()
//e.doWork()

class Pets {
    var name: String = ""
    var age: Int = 0
    
    func feed() {
        print("\(name) has been fed")
    }
    func clean() {
        print("\(name) has taken a bath")
    }
    func play() {
        print("\(name) enjoyed playing with you")
    }
    func sleep() {
        print("\(name) went to sleep")
    }
    
}

var pet = Pets()
pet.name = "dog"
pet.feed()
pet.clean()
pet.play()
pet.sleep()

class Tamagotchi: Pets {
    var hunger: Int = 0
    var dirt: Int = 0
    var boredom: Int = 0
    var drowsiness: Int = 0
    
    override func feed() {
        super.feed()
        hunger = 0
        boredom += 20
        dirt += 20
        drowsiness += 10
    }
    
    override func clean() {
        super.clean()
        dirt = 0
        hunger += 20
        boredom += 20
        drowsiness += 10
    }
    
    override func play() {
        super.play()
        boredom = 0
        hunger += 20
        dirt += 20
        drowsiness += 10
    }
    
    override func sleep() {
        super.sleep()
        drowsiness = 0
        boredom += 20
        hunger += 20
        dirt += 10
        
    }
    
    func check() {
        print(hunger, dirt, boredom, drowsiness)
    }
    
}

var game = Tamagotchi()
game.name = "Cat"
game.clean()
game.feed()
game.check()
game.play()
game.sleep()

class Person {
    var name: String
    var netWorth: Int?
    var gender: String!
    
    // Designated initializer because it makes sure that all properties are initialized
    init() {
        name = "None"
    }
    
    convenience init(_ gender: String, _ netWorth: Int) {
        // call the designated initializer to make sure that the object is ready to go
        self.init()
        
        // Set any other properties or custom code to initialize for this scenario
        self.gender = gender
        self.netWorth = netWorth
    }
}

let klkl = Person ()

let richperopl = Person ("female", 5645646)

var myArray = ["Dog", "Cat", "Bird"]

for counter in 0...2 {
    myArray[counter] = "My " + myArray[counter]
    print(myArray[counter])
}

//Add items
myArray.insert("Frog", at: 0)
for item in myArray {
    print(item)
}


