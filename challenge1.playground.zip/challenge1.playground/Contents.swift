import Cocoa

var lastName: String = "He"

var firstName: String = "Ye"

let gender: String = "Male"

var age: Int = 80

var cashOnHand: Double = 300000

var hasChildren: Bool = false

if hasChildren == true {
    print("Being hard, my money goes to my children instead of games")
}

else if age > 18 {
    print("Adulting is hard I can't buy the game because I need to pay bills")
}
else{
    "I'm young and I can do what I want so gimme that game!"
}

var strOperator: String = "/"

var num1: Int = 578

var num2: Int = 897

var result: Int

switch strOperator {
case "+":
    result = num1 + num2
    print(result)
case "-":
    result = num2 - num1
    print(result)
case "*", "x":
    result = num1 * num2
    print(result)
case "/":
    result = num2 / num1
    print(result)
case "^":
    result = num1 ^ 2
    print(result)
default:
    print("Operator does not exist")
}

var drawPixel: String = "*"
var height: Int = 10
var tempRow: String = ""

for columnPixel in 1...height {
    tempRow = ""
    for _ in 1...columnPixel {
        tempRow += drawPixel
    }
    print(tempRow)
}
